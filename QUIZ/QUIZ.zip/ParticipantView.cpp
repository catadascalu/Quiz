#include "ParticipantView.h"

ParticipantView::ParticipantView(Participant& p1, Presenter & p, QWidget * parent) : QWidget(parent), participant{ p1 }, presenter { p }
{
	ui.setupUi(this);

	this->presenter.addObserver(this);
	this->populateListObs();
	//this->connectSignals();
}

ParticipantView::~ParticipantView()
{
	this->presenter.removeObserver(this);
}

void ParticipantView::update()
{
	this->populateListObs();
}

void ParticipantView::populateListObs()
{
	ui.questionTable->clear();
	int index;
	ui.questionTable->setRowCount(this->presenter.getQs().size());

	index = 0;
	this->presenter.sortScore();
	for (auto q : this->presenter.getQs())
	{
		ui.questionTable->setItem(index, 0, new QTableWidgetItem(QString::fromStdString(std::to_string(q.getId()))));
		ui.questionTable->setItem(index, 1, new QTableWidgetItem(QString::fromStdString(q.getText())));
		ui.questionTable->setItem(index, 2, new QTableWidgetItem(QString::fromStdString(std::to_string(q.getScore()))));
		index++;
	}
}
