#pragma once
#include<QWidget>
#include<qtablewidget.h>
#include "ui_ParticipantView.h"
#include "Observer.h"
#include "Presenter.h"
#include "Participant.h"

class ParticipantView :public QWidget, public Observer
{
	Q_OBJECT
public:
	Participant & participant;
	Presenter & presenter;
public:
	ParticipantView(Participant& p1, Presenter& p, QWidget* parent = Q_NULLPTR);
	~ParticipantView();

	void update() override;

private:

	Ui::ParticipantView ui;
	void populateListObs();
	//void connectSignals();

};