#include "QUIZ.h"

QUIZ::QUIZ(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);
}
