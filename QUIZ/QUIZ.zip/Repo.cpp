#include "Repo.h"

void Repo::loadFromFile(std::string filename)
{
	ifstream file(filename);
	if (file.is_open())
	{
		Participant p = Participant();
		while (file >> p)
		{
			this->participants.push_back(p);
		}
		file.close();
	}
}
